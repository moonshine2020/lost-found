return {
  ["workshop-1153998909"]={
    configuration_options={
      [""]=0,
      ARMOR_BONE_BLOCK_VALUE=0.8,
      ARMOR_BONE_DURABILITY_MULTIPLICATOR=5,
      ARMOR_BONE_INGREDIENT_BONES=6,
      ARMOR_BONE_INGREDIENT_ROPE=2,
      ARMOR_STONE_BLOCK_VALUE=0.8,
      ARMOR_STONE_DURABILITY_MULTIPLICATOR=2.5,
      ARMOR_STONE_INGREDIENT_ROCKS=6,
      ARMOR_STONE_INGREDIENT_ROPE=2,
      ["BONE SUIT CONFIG:"]=0,
      ["STONE SUIT CONFIG:"]=0 
    },
    enabled=true 
  },
  ["workshop-1207269058"]={ configuration_options={  }, enabled=true },
  ["workshop-1530801499"]={
    configuration_options={ Hunger_Cost=1, Ownership=false, Sanity_Cost=1 },
    enabled=true 
  },
  ["workshop-2078243581"]={
    configuration_options={ Blue=0, Display="target", Green=0, Projectile=true, Red=1, Type="hit" },
    enabled=true 
  },
  ["workshop-2120520446"]={
    configuration_options={
      goldnugget=0,
      livinglog=0,
      machine=0,
      modModeHost=0,
      nightmarefuel=0,
      purplegem=0 
    },
    enabled=true 
  },
  ["workshop-2166704267"]={
    configuration_options={ ENABLEBACKPACK=false, EXTRASLOT=0, INVENTORYSIZE=45 },
    enabled=true 
  },
  ["workshop-2172284661"]={
    configuration_options={
      MOD_RESTART_ALLOW_KILL=true,
      MOD_RESTART_ALLOW_RESTART=true,
      MOD_RESTART_ALLOW_RESURRECT=true,
      MOD_RESTART_CD_KILL=3,
      MOD_RESTART_CD_RESTART=5,
      MOD_RESTART_CD_RESURRECT=7,
      MOD_RESTART_FORCE_DROP_MODE=1,
      MOD_RESTART_IGNORING_ADMIN=true,
      MOD_RESTART_TRIGGER_MODE=1,
      MOD_RESTART_WELCOME_TIPS=true,
      MOD_RESTART_WELCOME_TIPS_TIME=6 
    },
    enabled=true 
  },
  ["workshop-356930882"]={
    configuration_options={ uses=10000000, uses2=10000000, uses3=10000000 },
    enabled=true 
  },
  ["workshop-362175979"]={ configuration_options={ ["Draw over FoW"]="disabled" }, enabled=true },
  ["workshop-378160973"]={
    configuration_options={
      ENABLEPINGS=true,
      FIREOPTIONS=2,
      OVERRIDEMODE=false,
      SHAREMINIMAPPROGRESS=true,
      SHOWFIREICONS=true,
      SHOWPLAYERICONS=true,
      SHOWPLAYERSOPTIONS=2 
    },
    enabled=true 
  },
  ["workshop-380423963"]={
    configuration_options={
      [""]=0,
      boulder_blue=0.2,
      boulder_purple=0.05,
      change_cave_loot=false,
      common_loot_charcoal=0,
      common_loot_flint=0.35,
      common_loot_rocks=0.35,
      cutlichen=0,
      durian=0,
      flintless_blue=0.5,
      flintless_purple=0.1,
      flintless_red=0.2,
      foliage=0,
      gears=0,
      goldvein_purple=0.05,
      goldvein_red=0.1,
      guano=0,
      ice=0,
      lightbulb=0,
      moon_green=0.02,
      moon_orange=0.02,
      moon_yellow=0.02,
      pinecone=0,
      rare_loot_bluegem=0.015,
      rare_loot_marble=0.015,
      rare_loot_redgem=0.015,
      rottenegg=0,
      seeds=0,
      spoiled_food=0,
      stalagmite_green=0.02,
      stalagmite_orange=0.02,
      stalagmite_yellow=0.02,
      uncommon_loot_goldnugget=0.05,
      uncommon_loot_mole=0.05,
      uncommon_loot_nitre=0.05,
      uncommon_loot_rabbit=0.05 
    },
    enabled=true 
  },
  ["workshop-466732225"]={ configuration_options={  }, enabled=true },
  ["workshop-501385076"]={
    configuration_options={ quick_cook_on_fire=true, quick_harvest=true },
    enabled=true 
  },
  ["workshop-661253977"]={
    configuration_options={ amudiao=true, baodiao=1, kong=0, nillots=0, rendiao=2, zbdiao=true },
    enabled=true 
  },
  ["workshop-972148976"]={ configuration_options={  }, enabled=true } 
}